package com.unimar;

public class Estudiante extends Persona {
    private double gradePointAverage;
    private int age;

    public Estudiante(String name, String lastName, int id, double gradePointAverage, int age) {
        super(name, lastName, id);
        this.gradePointAverage = gradePointAverage;
        this.age = age;
    }

    public double getGradePointAverage() {
        return gradePointAverage;
    }

    public void setGradePointAverage(double gradePointAverage) {
        this.gradePointAverage = gradePointAverage;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Nombre: " + this.getName()+" Aepplido: "+this.getLastName()+
                " Cédula: "+this.getId()+ " Promedio: "+this.getGradePointAverage()+
                " Edad: "+ age;
    }
}
