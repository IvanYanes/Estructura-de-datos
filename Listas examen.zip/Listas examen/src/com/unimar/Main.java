package com.unimar;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        System.out.println("\n" +
                "\t##########°###################°##########\n" +
                "\t#########°°°#################°°°#########\n" +
                "\t######°°°°°°#################°°°°°°######\n" +
                "\t####°°°°°°°°#################°°°°°°°°####\n" +
                "\t###°°°°°°°°°#################°°°°°°°°°###\n" +
                "\t###°°°°°°°°°#################°°°°°°°°°###\n" +
                "\t###°°°°°°°°°°###############°°°°°°°°°°###\n" +
                "\t####°°°°°°°°°°#############°°°°°°°°°°####\n" +
                "\t#####°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°#####\n" +
                "\t#######°°°°°°°°°°°°°°°°°°°°°°°°°°°#######\n" +
                "\t###°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°###\n" +
                "\t###°°°°°°°°°°°°°#########°°°°°°°°°°°°°###\n" +
                "\t###°°°°°°°°°°°°°°#######°°°°°°°°°°°°°°###\n" +
                "\t###°°°°°°°°°°°°°°°#####°°°°°°°°°°°°°°°###\n" +
                "\t###°°°°°°°°°##°°°°°###°°°°°°#°°°°°°°°°###\n" +
                "\t####°°°°°°°°##°°°°°°°°°°°°°##°°°°°°°°####\n" +
                "\t######°°°°°°####°°°°°°°°°°###°°°°°°######\n" +
                "\t#########°°°#####°°°°°°°#####°°°#########\n" +
                "\t##################°°°°°##################\n" +
                "\t\tUNIVERSIDAD DE MARGARITA\n\t\t ALMA MATER DEL CARIBE\n" +
                "\t\tEstructura de Datos T-01\n" +
                "\t\tDocente: Silvestre Cárdenas\n" +
                "\t\tRealizado por:Ivan Yanes\n" +
                "\t\tCi:28043565\n");
        String option;
        boolean exit=true;
        do {
            System.out.println("\t\t\t\tMenú");
            System.out.println("Digite el numero correspondeinte a la opción: ");
            System.out.println("1) Calcular el promedio de notas general del listado contenido en el archivo: Estudiantes.in");
            System.out.println("2) Reccorer una lista circular doblemente\n" +
                    "enlazada y imprimir un elemento aleatoriamente");
            System.out.println("3) Determinar el valor mas alto, el mas bajo y la\n" +
                    "mediana en una lista doblemente enlazada (en este caso la edad)");
            System.out.println("4) eliminar elementos de una lista de personas,\n" +
                    "usando la cédula");
            System.out.println("5) Salir");
            Scanner input = new Scanner (System.in);
            option=input.nextLine();
            if(option.equals("1")) {
                Tools.getOverallGradePointAverageOfAFileListing("Estudiantes.in", ",");
            } else if(option.equals("2")) {
                Tools.getRandomElementInCircularList("Estudiantes.in", ",");
            } else if(option.equals("3")) {
                Tools.getHigtLowAndaverage("Estudiantes.in", ",");
            }else if(option.equals("4")) {
                Tools.removeItemById("Estudiantes.in", ",");
            }else if(option.equals("5")) {
                System.exit(0);
            } else {
                System.out.println("Ha digitado una opción invalida, las opciones validas son: “1”, “2”, “3”, “4” y 5");
            }
        }while (exit);

    }
}
