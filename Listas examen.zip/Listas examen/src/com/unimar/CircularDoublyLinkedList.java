package com.unimar;

public class CircularDoublyLinkedList {
    private Node begin;
    private Node end;
    private Node location;
    private int numberOfElements;
    private boolean found;

    public CircularDoublyLinkedList() {
        begin = null;
        end = null;
        numberOfElements = 0;
        location = null;
    }

    public boolean isEmpty() {
        return (begin == null);
    }

    public int size() {
        return numberOfElements;
    }

    protected void find(Estudiante target) {
        location = begin;
        found = false;
        if (!isEmpty()) {
            do {
                if (location.getData().equals(target))
                {
                    found = true;
                    return;
                } else {
                    location = location.getNext();
                }
            } while (location != end.getNext());
        }

    }

    public boolean contains(Estudiante element) {
        find(element);
        return found;
    }

    protected void findPosition(int position) {
        int start = 0;
        location = begin;
        found = false;

        if ((!isEmpty()) && (position >= 0) && (position <= size())) {
            do {
                // move search to the next node
                location = location.getNext();
                start++;

            } while ((location != begin) && start < position);
            found = true;
        }

    }

    protected Estudiante getInPosition(int position) {
        int start = 0;
        location = begin;
        Estudiante found = null;

        if ((!isEmpty()) && (position >= 0) && (position <= size())) {
            do {
                // move search to the next node
                location = location.getNext();
                start++;

            } while ((location != begin) && start < position);
            found = location.data;
        }
        return found;
    }

    public Estudiante get(Estudiante data) {
        find(data);
        if (found)
            return location.getData();
        else
            return null;
    }

    public void reset() {
        location = begin;
    }

    public void add(Estudiante data) {
        Node newNode = new Node(data);

        if (isEmpty())
        {
            begin = newNode;
            end = newNode;
            begin.setPrevious(end);
            end.setNext(begin);
        } else
        {
            end.setNext(newNode);
            newNode.setPrevious(end);
            end = newNode;
            end.setNext(begin);
        }
        numberOfElements++;
    }

    public void addFront(Estudiante data) {
        Node newNode = new Node(data);

        if (isEmpty())
        {
            begin = newNode;
            end = newNode;
            begin.setPrevious(end);
            end.setNext(begin);
        } else
        {
            newNode.setNext(begin);
            begin.setPrevious(newNode);
            begin = newNode;
            begin.setPrevious(end);
            end.setNext(begin);
        }
        numberOfElements++;

    }

    public void addBack(Estudiante data) {
        Node newNode = new Node(data);

        if (isEmpty())
        {
            begin = newNode;
            end = newNode;
            begin.setPrevious(end);
            end.setNext(begin);
        } else
        {
            end.setNext(newNode);
            newNode.setPrevious(end);
            end = newNode;
            end.setNext(begin);
        }
        numberOfElements++;

    }

    public void addAtPosition(Estudiante data, int position) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            begin = newNode;
            end = newNode;
            begin.setPrevious(end);
            end.setNext(begin);

        } else if (position <= 0) {
            newNode.setNext(begin);
            begin.setPrevious(newNode);
            begin = newNode;
            begin.setPrevious(end);
            end.setNext(begin);

        } else if (position >= size()) {
            end.setNext(newNode);
            newNode.setPrevious(end);
            end = newNode;
            end.setNext(begin);

        } else {
            findPosition(position);
            newNode.setPrevious(location.getPrevious());
            newNode.setNext(location);
            location.getPrevious().setNext(newNode);
            location.setPrevious(newNode);
        }
        numberOfElements++;
    }

    protected Estudiante find(int ci) {
        location = begin;
        found = false;
        if (!isEmpty()) {
            do {
                if (location.getData().getId() == ci)
                {
                    found = true;
                    return location.getData();
                } else {
                    location = location.getNext();
                }
            } while (location != end.getNext());
        }
        return null;
    }

    public boolean remove(Estudiante element) {
        find(element);
        if (found) {
            if (location == begin && size() == 1)
            //empties the list
            {
                begin = null;
                end = null;

            } else if (location == begin)
            {
                begin = begin.getNext();
                begin.setPrevious(end);
                end.setNext(begin);

            } else if (location == end)
            {

                end = end.getPrevious();
                end.setNext(begin);
                begin.setPrevious(end);
            } else {
                location.getPrevious().setNext(location.getNext());
                location.getNext().setPrevious(location.getPrevious());
            }
            numberOfElements--;
        }
        return found;
    }

    public void removeFront() {

        if (!isEmpty()) {
            if (begin.getNext() == begin) {
                begin = null;
                end = null;
            } else {
                begin = begin.getNext();
                begin.setPrevious(end);
                end.setNext(begin);
            }
        }
        numberOfElements--;
    }

    public void removeBack() {
        if (!isEmpty()) {

            if (begin.getNext() == begin) {
                begin = null;
                end = null;
            } else {
                end = end.getPrevious();
                end.setNext(begin);
                begin.setPrevious(end);
            }
        }
        numberOfElements--;
    }

    public void removeAtPosition(int position) {
        if (position <= 0) {
            begin = begin.getNext();
            begin.setPrevious(end);
            end.setNext(begin);
        } else if (position >= size() - 1) {

            end = end.getPrevious();
            end.setNext(begin);
            begin.setPrevious(end);

        } else {
            findPosition(position);
            location.getPrevious().setNext(location.getNext());
            location.getNext().setPrevious(location.getPrevious());
        }
        numberOfElements--;
    }

    public void getHigtLowAndaverage() {
        int minimum = 99999999, maximum = 0, average = 0, temp = 0, elements = 0;
        Node current = begin;
        if (!isEmpty()) {
            do {
                temp = current.getData().getAge();
                maximum = Integer.max(maximum, temp);
                minimum = Integer.min(minimum, temp);
                average += temp;
                elements++;
                current = current.getNext();
            } while (current != begin);
            average /= elements;
        }
        System.out.println("La edad más alta es: " + maximum +
                "\nLa menor edad es: " + minimum +
                "\nEl promedio de las edades es: " + average);
    }

    public void print()
    {
        String item = "List: [ ";
        Node current = begin;
        if (!isEmpty()) {
            do {
                item += current.getData() + " ";
                current = current.getNext();
            } while (current != begin);

        }
        item += "]";
        System.out.println(item);
    }
}


