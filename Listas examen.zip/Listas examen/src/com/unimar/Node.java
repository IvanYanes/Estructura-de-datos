package com.unimar;

public class Node {
    protected Node next;
    protected Node previous;
    protected Estudiante data;

    public Node(Estudiante data)
    {
        this.data = data;
        next = null;
        previous = null;
    }

    public Node getNext()
    {
        return next;
    }

    public void setNext(Node next)
    {
        this.next = next;
    }

    public Estudiante getData()
    {
        return data;
    }

    public void setData(Estudiante data)
    {
        this.data = data;
    }

    public Node getPrevious()
    {
        return previous;
    }

    public void setPrevious(Node previous)
    {
        this.previous = previous;
    }
}
