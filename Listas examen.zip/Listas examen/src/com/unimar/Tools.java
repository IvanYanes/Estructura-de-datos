package com.unimar;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Tools {

    static public void serialize(List<Persona> people, String fileName) {
        FileOutputStream file = null;
        ObjectOutputStream output = null;
        try {
            file = new FileOutputStream(fileName);
            output = new ObjectOutputStream(file);
            output.writeObject(people);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static public double getOverallAverage(List<Estudiante> studentList) {
        double OverallAverage = 0;
        for (Estudiante people : studentList) {
            OverallAverage += people.getGradePointAverage();
        }
        OverallAverage /= studentList.size();
        return OverallAverage;
    }

    static public void getOverallGradePointAverageOfAFileListing(String fileName, String separator) {
        List<Estudiante> studentList = new ArrayList<Estudiante>();
        String[] rowData;
        int lineCounter = 0, studentCounter = 0;
        BufferedReader Buffer = null;
        try {
            Buffer = new BufferedReader(new FileReader(fileName));
            String texto = Buffer.readLine();
            while (texto != null) {
                lineCounter++;
                rowData = Tools.split(texto, separator);
                if (rowData.length == 5) {//es un estudiante
                    Estudiante people = new Estudiante(
                            rowData[0],//Nombre
                            rowData[1],//Apellido
                            getInteger(rowData[2]),//Cédula
                            getDouble(rowData[3]),//promedio
                            getInteger(rowData[4]));//edad
                    studentCounter++;
                    studentList.add(people);
                } else {//Formato incorrectp

                    System.err.println("La linea " + lineCounter + " del archivo: " + fileName +
                            " no cumple con el formato valido\n el separador es la , \n Ejemplo: " +
                            "Pedro,Perez,27125244");
                }
                texto = Buffer.readLine();//Leer la siguiente línea
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Fichero no encontrado\n" +
                    "Verifique que el archivo este en el directorio de ejecución");
            System.exit(1);
        } catch (Exception e) {
            System.err.println("Error de lectura del fichero\n" +
                    "Verifique que exista el archivo en el directorio y" +
                    " que tenga permisos de lectura del archivo");
            System.exit(1);
        } finally {
            try {
                if (Buffer != null)
                    Buffer.close();
            } catch (Exception e) {
                System.err.println("Error al cerrar el archivo");
                System.out.println(e.getMessage());
            }
        }
        System.out.println("El promedio general de los " + studentList.size() +
                " estudiantes es de: ");
        System.out.printf("%.3f", getOverallAverage(studentList));//mostramos el promedio con 3 decimales
        System.out.println(" puntos");
    }

    static public double getDouble(String Float) {
        double number = 0;
        try {
            number = Double.parseDouble(Float);
        } catch (NumberFormatException e) {
            System.err.println("Formato del promedio incorrecto");
            number = 0;
        }
        return number;
    }

    static public int getInteger(String integer) {
        int number = 0;
        try {
            number = Integer.parseInt(integer);
        } catch (NumberFormatException e) {
            System.err.println("Formato de la cédula incorrecto");
            System.out.println(integer);
            number = 0;
        }
        return number;
    }

    static String[] split(String text, String separator) {
        String[] parts = text.split(separator);
        return parts;
    }


    static public void getRandomElementInCircularList(String fileName, String separator) {
        CircularDoublyLinkedList studentList = new CircularDoublyLinkedList();
        String[] rowData;
        int lineCounter = 0;
        BufferedReader Buffer = null;
        try {
            Buffer = new BufferedReader(new FileReader(fileName));
            String texto = Buffer.readLine();
            while (texto != null) {
                lineCounter++;
                rowData = Tools.split(texto, separator);
                if (rowData.length == 5) {//es un estudiante
                    Estudiante people = new Estudiante(
                            rowData[0],//Nombre
                            rowData[1],//Apellido
                            getInteger(rowData[2]),//Cédula
                            getDouble(rowData[3]),//promedio
                            getInteger(rowData[4]));//edad
                    studentList.add(people);
                } else {//Formato incorrectp

                    System.err.println("La linea " + lineCounter + " del archivo: " + fileName +
                            " no cumple con el formato valido\n el separador es la , \n Ejemplo: " +
                            "Pedro,Perez,27125244");
                }
                texto = Buffer.readLine();//Leer la siguiente línea
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Fichero no encontrado\n" +
                    "Verifique que el archivo este en el directorio de ejecución");
            System.exit(1);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (Buffer != null)
                    Buffer.close();
            } catch (Exception e) {
                System.err.println("Error al cerrar el archivo");
                System.out.println(e.getMessage());
            }
        }
        int randomNumber = (int) (Math.random() * studentList.size() + 1);
        System.out.println("El elemento aleatorio de la lista circular es: " + studentList.get(studentList.getInPosition(randomNumber)).toString());
    }

    static public void removeItemById(String fileName, String separator) {
        CircularDoublyLinkedList studentList = new CircularDoublyLinkedList();
        String[] rowData;
        int lineCounter = 0;
        BufferedReader Buffer = null;
        try {
            Buffer = new BufferedReader(new FileReader(fileName));
            String texto = Buffer.readLine();
            while (texto != null) {
                lineCounter++;
                rowData = Tools.split(texto, separator);
                if (rowData.length == 5) {//es un estudiante
                    Estudiante people = new Estudiante(
                            rowData[0],//Nombre
                            rowData[1],//Apellido
                            getInteger(rowData[2]),//Cédula
                            getDouble(rowData[3]),//promedio
                            getInteger(rowData[4]));//edad
                    studentList.add(people);
                } else {//Formato incorrectp

                    System.err.println("La linea " + lineCounter + " del archivo: " + fileName +
                            " no cumple con el formato valido\n el separador es la , \n Ejemplo: " +
                            "Pedro,Perez,27125244");
                }
                texto = Buffer.readLine();//Leer la siguiente línea
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Fichero no encontrado\n" +
                    "Verifique que el archivo este en el directorio de ejecución");
            System.exit(1);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (Buffer != null)
                    Buffer.close();
            } catch (Exception e) {
                System.err.println("Error al cerrar el archivo");
                System.out.println(e.getMessage());
            }
        }
        System.out.println("Imprimimos la lista antes de eliminar el nodo");
        studentList.print();
        System.out.println("Digite la cédula de la paersona que desea eliminar de la lista ");
        Scanner input = new Scanner(System.in);
        studentList.remove(studentList.find(getInteger(input.nextLine())));
        System.out.println("Imprimimos la lista depues de eliminar el nodo");
        studentList.print();
    }



    static public void getHigtLowAndaverage(String fileName, String separator) {
        CircularDoublyLinkedList studentList = new CircularDoublyLinkedList();
        String[] rowData;
        int lineCounter = 0;
        BufferedReader Buffer = null;
        try {
            Buffer = new BufferedReader(new FileReader(fileName));
            String texto = Buffer.readLine();
            while (texto != null) {
                lineCounter++;
                rowData = Tools.split(texto, separator);
                if (rowData.length == 5) {//es un estudiante
                    Estudiante people = new Estudiante(
                            rowData[0],//Nombre
                            rowData[1],//Apellido
                            getInteger(rowData[2]),//Cédula
                            getDouble(rowData[3]),//promedio
                            getInteger(rowData[4]));//edad
                    studentList.add(people);
                } else {//Formato incorrectp

                    System.err.println("La linea " + lineCounter + " del archivo: " + fileName +
                            " no cumple con el formato valido\n el separador es la , \n Ejemplo: " +
                            "Pedro,Perez,27125244");
                }
                texto = Buffer.readLine();//Leer la siguiente línea
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: Fichero no encontrado\n" +
                    "Verifique que el archivo este en el directorio de ejecución");
            System.exit(1);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (Buffer != null)
                    Buffer.close();
            } catch (Exception e) {
                System.err.println("Error al cerrar el archivo");
                System.out.println(e.getMessage());
            }
        }
        studentList.getHigtLowAndaverage();
    }
}
